package Collection_Q10;

public class Node10 {
	int data;
	Node10 left, right;

	Node10(int d) {
		data = d;
		left = right = null;
	}
}
